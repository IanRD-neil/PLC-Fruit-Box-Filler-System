﻿import QtQuick 2.7
import "qrc:/"
IGuiPage
{
	id: q16777217
	objId: 16777217
	x: 0
	y: 0
	width: 800
	height: 480
	IGuiAlarmView
	{
		id: q402653184
		objId: 402653184
		x: 26
		y: 21
		width: 733
		height: 160
		qm_BorderCornerRadius: 4
		qm_BorderWidth: 1
		qm_RectangleBorder.color:"#ff6b717b"
		qm_FillColor: "#fff7f3f7"
		IGuiListCtrl
		{
			id: qu402653184
			objectName: "qu402653184"
			x: 2
			y: 2
			width: 729
			height: 104
			qm_list.qm_linesPerRow: 1
			qm_list.qm_tableRowHeight: 18
			qm_list.qm_tableMarginLeft: 2
			qm_list.qm_tableMarginRight: 1
			qm_list.qm_tableMarginBottom: 1
			qm_list.qm_tableMarginTop: 1
			qm_list.qm_tableBackColor: "#ffffffff"
			qm_list.qm_tableSelectBackColor: "#ff94b6e7"
			qm_list.qm_tableAlternateBackColor: "#ffe7e7ef"
			qm_list.qm_tableTextColor: "#ff181c31"
			qm_list.qm_tableSelectTextColor: "#ffffffff"
			qm_list.qm_tableAlternateTextColor: "#ff181c31"
			qm_scrollCtrl: qus402653184

			qm_hasHeader: true
			qm_hasBorder: true
			qm_hasHorizontalScrollBar: false
			qm_hasVerticalScrollBar: true
			qm_list.qm_gridLineStyle: 0
			qm_list.qm_gridLineWidth: 0
			qm_list.qm_gridLineColor: "#ffffffff"
			qm_columnTypeList: [0, 0, 0, 0, 0, 0, 0]
			totalColumnWidth: 695
			qm_headerItem: qh402653184
			IGuiListHeader
			{
				id: qh402653184
				width: 695
				qm_listItem: qu402653184
				qm_columnWidthList: [26, 68, 96, 88, 60, 199, 158]
				color: "#ff84868c"
				qm_tableHeaderTextColor: "#ffffffff"
				qm_tableHeaderValueVarTextAlignmentHorizontal: Text.AlignLeft
				qm_tableHeaderValueVarTextAlignmentVertical: Text.AlignVCenter
				qm_tableHeaderMarginLeft: 7
				qm_tableHeaderMarginRight: 5
				qm_tableHeaderMarginBottom: 5
				qm_tableHeaderMarginTop: 5
				qm_noOfColumns: 7
				qm_tableHeaderHeight: 18
				qm_leftImageID: 70
				qm_leftTileTop: 6
				qm_leftTileBottom: 15
				qm_leftTileRight: 6
				qm_leftTileLeft: 6
				qm_middleImageID: 71
				qm_middleTileTop: 6
				qm_middleTileBottom: 15
				qm_middleTileRight: 6
				qm_middleTileLeft: 6
				qm_rightImageID: 72
				qm_rightTileTop: 6
				qm_rightTileBottom: 15
				qm_rightTileRight: 6
				qm_rightTileLeft: 6
				radius: 2
			}
			IGuiListScrollBarCtrl
			{
				id: qus402653184

			}
		}
		IGuiGraphicButton
		{
			id: q486539318
			objId: 486539318
			x: 673
			y: 116
			width: 56
			height: 40
			qm_BorderCornerRadius: 3
			qm_BorderWidth: 1
			qm_ImageSource: "image://QSmartImageProvider/32#2#4#128#0#0"
			qm_Border.top: 15
			qm_Border.bottom: 15
			qm_Border.right: 5
			qm_Border.left: 5
			qm_FillColor: "#ffefebef"
			qm_FocusWidth: 2
			qm_FocusColor: "#ff94b6e7"
			qm_ImageFillMode:6
			qm_ImagePossitionX: 3
			qm_ImagePossitionY: 2
			qm_ImageWidth: 51
			qm_ImageHeight: 36
			qm_SourceSizeWidth: 51
			qm_SourceSizeHeight: 36
		}
	}
	IGuiAlarmView
	{
		id: q402653185
		objId: 402653185
		x: 28
		y: 194
		width: 732
		height: 187
		qm_BorderCornerRadius: 4
		qm_BorderWidth: 1
		qm_RectangleBorder.color:"#ff6b717b"
		qm_FillColor: "#fff7f3f7"
		IGuiListCtrl
		{
			id: qu402653185
			objectName: "qu402653185"
			x: 2
			y: 2
			width: 728
			height: 122
			qm_list.qm_linesPerRow: 1
			qm_list.qm_tableRowHeight: 18
			qm_list.qm_tableMarginLeft: 2
			qm_list.qm_tableMarginRight: 1
			qm_list.qm_tableMarginBottom: 1
			qm_list.qm_tableMarginTop: 1
			qm_list.qm_tableBackColor: "#ffffffff"
			qm_list.qm_tableSelectBackColor: "#ff94b6e7"
			qm_list.qm_tableAlternateBackColor: "#ffe7e7ef"
			qm_list.qm_tableTextColor: "#ff181c31"
			qm_list.qm_tableSelectTextColor: "#ffffffff"
			qm_list.qm_tableAlternateTextColor: "#ff181c31"
			qm_scrollCtrl: qus402653185

			qm_hasHeader: true
			qm_hasBorder: true
			qm_hasHorizontalScrollBar: false
			qm_hasVerticalScrollBar: true
			qm_list.qm_gridLineStyle: 0
			qm_list.qm_gridLineWidth: 0
			qm_list.qm_gridLineColor: "#ffffffff"
			qm_columnTypeList: [0, 0, 0, 0, 0, 0, 0]
			totalColumnWidth: 694
			qm_headerItem: qh402653185
			IGuiListHeader
			{
				id: qh402653185
				width: 694
				qm_listItem: qu402653185
				qm_columnWidthList: [26, 68, 96, 88, 60, 198, 158]
				color: "#ff84868c"
				qm_tableHeaderTextColor: "#ffffffff"
				qm_tableHeaderValueVarTextAlignmentHorizontal: Text.AlignLeft
				qm_tableHeaderValueVarTextAlignmentVertical: Text.AlignVCenter
				qm_tableHeaderMarginLeft: 7
				qm_tableHeaderMarginRight: 5
				qm_tableHeaderMarginBottom: 5
				qm_tableHeaderMarginTop: 5
				qm_noOfColumns: 7
				qm_tableHeaderHeight: 18
				qm_leftImageID: 70
				qm_leftTileTop: 6
				qm_leftTileBottom: 15
				qm_leftTileRight: 6
				qm_leftTileLeft: 6
				qm_middleImageID: 71
				qm_middleTileTop: 6
				qm_middleTileBottom: 15
				qm_middleTileRight: 6
				qm_middleTileLeft: 6
				qm_rightImageID: 72
				qm_rightTileTop: 6
				qm_rightTileBottom: 15
				qm_rightTileRight: 6
				qm_rightTileLeft: 6
				radius: 2
			}
			IGuiListScrollBarCtrl
			{
				id: qus402653185

			}
		}
		IGuiGraphicButton
		{
			id: q486539319
			objId: 486539319
			x: 672
			y: 143
			width: 56
			height: 40
			qm_BorderCornerRadius: 3
			qm_BorderWidth: 1
			qm_ImageSource: "image://QSmartImageProvider/32#2#4#128#0#0"
			qm_Border.top: 15
			qm_Border.bottom: 15
			qm_Border.right: 5
			qm_Border.left: 5
			qm_FillColor: "#ffefebef"
			qm_FocusWidth: 2
			qm_FocusColor: "#ff94b6e7"
			qm_ImageFillMode:6
			qm_ImagePossitionX: 3
			qm_ImagePossitionY: 2
			qm_ImageWidth: 51
			qm_ImageHeight: 36
			qm_SourceSizeWidth: 51
			qm_SourceSizeHeight: 36
		}
	}
	IGuiButton
	{
		id: q486539317
		objId: 486539317
		x: 528
		y: 394
		width: 133
		height: 58
		qm_BorderCornerRadius: 3
		qm_BorderWidth: 2
		qm_ImageSource: "image://QSmartImageProvider/19#2#4#128#0#0"
		qm_Border.top: 15
		qm_Border.bottom: 15
		qm_Border.right: 5
		qm_Border.left: 5
		qm_FillColor: "#ff636573"
		qm_TextColor: "#ffffffff"
		qm_ValueVarTextAlignmentHorizontal: Text.AlignHCenter
		qm_ValueVarTextAlignmentVertical: Text.AlignVCenter
		qm_Anchors.bottomMargin: 2
		qm_Anchors.leftMargin: 2
		qm_Anchors.rightMargin: 2
		qm_Anchors.topMargin: 2
		qm_FocusWidth: 2
		qm_FocusColor: "#ff94b6e7"
	}
}
