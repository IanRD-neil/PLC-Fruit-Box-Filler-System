﻿import QtQuick 2.7
import "qrc:/"
IGuiPage
{
	id: q16777216
	objId: 16777216
	x: 0
	y: 0
	width: 800
	height: 480
	IGuiSymbolicIoOutput
	{
		id: q335544321
		objId: 335544321
		x: 15
		y: 25
		width: 130
		height: 37
		qm_BorderCornerRadius: 3
		qm_BorderWidth: 4
		qm_ImageSource: "image://QSmartImageProvider/20#2#4#128#0#0"
		qm_Border.top: 5
		qm_Border.bottom: 5
		qm_Border.right: 5
		qm_Border.left: 5
		qm_FillColor: "#ffffffff"
		qm_TextColor: "#ff31344a"
		qm_ValueVarTextAlignmentVertical: Text.AlignVCenter
		qm_Anchors.bottomMargin: 6
		qm_Anchors.leftMargin: 7
		qm_Anchors.rightMargin: 6
		qm_Anchors.topMargin: 6
	}
	IGuiIOField
	{
		id: q33554437
		objId: 33554437
		x: 323
		y: 31
		width: 52
		height: 31
		qm_BorderCornerRadius: 3
		qm_BorderWidth: 4
		qm_ImageSource: "image://QSmartImageProvider/21#2#4#128#0#0"
		qm_Border.top: 5
		qm_Border.bottom: 5
		qm_Border.right: 5
		qm_Border.left: 5
		qm_FillColor: "#ffffffff"
		qm_TextColor: "#ff31344a"
		qm_ValueVarTextAlignmentVertical: Text.AlignVCenter
		qm_Anchors.bottomMargin: 6
		qm_Anchors.leftMargin: 7
		qm_Anchors.rightMargin: 6
		qm_Anchors.topMargin: 6
	}
	IGuiIOField
	{
		id: q33554438
		objId: 33554438
		x: 521
		y: 31
		width: 82
		height: 31
		qm_BorderCornerRadius: 3
		qm_BorderWidth: 4
		qm_ImageSource: "image://QSmartImageProvider/21#2#4#128#0#0"
		qm_Border.top: 5
		qm_Border.bottom: 5
		qm_Border.right: 5
		qm_Border.left: 5
		qm_FillColor: "#ffffffff"
		qm_TextColor: "#ff31344a"
		qm_ValueVarTextAlignmentVertical: Text.AlignVCenter
		qm_Anchors.bottomMargin: 6
		qm_Anchors.leftMargin: 7
		qm_Anchors.rightMargin: 6
		qm_Anchors.topMargin: 6
	}
	IGuiTextField
	{
		id: q268435465
		objId: 268435465
		x: 158
		y: 35
		width: 144
		height: 23
		qm_Transparent : true 
		qm_TextColor: "#ff31344a"
		qm_ValueVarTextAlignmentVertical: Text.AlignVCenter
		qm_Anchors.bottomMargin: 2
		qm_Anchors.leftMargin: 3
		qm_Anchors.rightMargin: 2
		qm_Anchors.topMargin: 2
	}
	IGuiTextField
	{
		id: q268435466
		objId: 268435466
		x: 396
		y: 35
		width: 107
		height: 23
		qm_Transparent : true 
		qm_TextColor: "#ff31344a"
		qm_ValueVarTextAlignmentVertical: Text.AlignVCenter
		qm_Anchors.bottomMargin: 2
		qm_Anchors.leftMargin: 3
		qm_Anchors.rightMargin: 2
		qm_Anchors.topMargin: 2
	}
	IGuiRectangle
	{
		id: q671088649
		objId: 671088649
		x: 220
		y: 299
		width: 495
		height: 47
		qm_BorderWidth: 3
		qm_TextColor: "#ff181c31"
		qm_FillColor: "#ff000000"
		qm_BorderStyle: 0
		qm_RectangleRadiusHorizontal: 50
		qm_RectangleRadiusVertical: 50
		qm_FillStyle: false
	}
	IGuiRectangle
	{
		id: q671088650
		objId: 671088650
		x: 64
		y: 157
		width: 472
		height: 48
		qm_BorderWidth: 3
		qm_TextColor: "#ff181c31"
		qm_FillColor: "#ff313000"
		qm_BorderStyle: 0
		qm_RectangleRadiusHorizontal: 50
		qm_RectangleRadiusVertical: 50
		qm_FillStyle: false
	}
	IGuiButton
	{
		id: q486539293
		objId: 486539293
		x: 535
		y: 393
		width: 133
		height: 60
		qm_BorderCornerRadius: 3
		qm_BorderWidth: 2
		qm_ImageSource: "image://QSmartImageProvider/19#2#4#128#0#0"
		qm_Border.top: 15
		qm_Border.bottom: 15
		qm_Border.right: 5
		qm_Border.left: 5
		qm_FillColor: "#ff636573"
		qm_TextColor: "#ffffffff"
		qm_ValueVarTextAlignmentHorizontal: Text.AlignHCenter
		qm_ValueVarTextAlignmentVertical: Text.AlignVCenter
		qm_Anchors.bottomMargin: 2
		qm_Anchors.leftMargin: 2
		qm_Anchors.rightMargin: 2
		qm_Anchors.topMargin: 2
		qm_FocusWidth: 2
		qm_FocusColor: "#ff94b6e7"
	}
	IGuiSliderSwitchHorizontal
	{
		id: q352321536
		objId: 352321536
		x: 619
		y: 21
		width: 156
		height: 50
		qm_BorderCornerRadius: 3
		qm_BorderWidth: 2
		qm_ImageSource: "image://QSmartImageProvider/23#2#4#128#0#0"
		qm_Border.top: 5
		qm_Border.bottom: 5
		qm_Border.right: 5
		qm_Border.left: 5
		qm_FillColor: "#ff636573"
		qm_TextColor: "#ff5a596b"
		qm_ValueVarTextAlignmentHorizontal: Text.AlignHCenter
		qm_ValueVarTextAlignmentVertical: Text.AlignVCenter
		qm_Anchors.bottomMargin: 2
		qm_Anchors.leftMargin: 2
		qm_Anchors.rightMargin: 2
		qm_Anchors.topMargin: 2
		qm_FocusWidth: 2
		qm_FocusColor: "#ff94b6e7"
		qm_SliderRectHeight: 49
		qm_SliderRectWidth: 77
		qm_SliderRectBorderCornerRadius: 3
		qm_SliderRectBorderWidth: 2
		qm_SliderRectImageID: 19
		qm_SliderRectTileTop: 15
		qm_SliderRectTileBottom: 15
		qm_SliderRectTileRight: 5
		qm_SliderRectTileLeft: 5
		qm_SliderGripBorderCornerRadius: 3
		qm_SliderGripBorderWidth: 2
		qm_SliderGripImageID: 24
		qm_SliderGripTileWidth: 8
		qm_SliderGripTileHeight: 56
		qm_SliderGripTileTop: 22
		qm_SliderGripTileBottom: 22
		qm_SliderGripTileRight: 0
		qm_SliderGripTileLeft: 0
		qm_SliderRectOffFillColor: "#fff7f3f7"
		qm_SliderRectOnFillColor: "#fff7f3f7"
		qm_SwichOnSide: false
		qm_SwitchOnValue: 1
	}
	IGuiQmlCircle
	{
		id: q671088651
		objId: 671088651
		x: 271
		y: 109
		width: 48
		height: 48
		qm_BorderWidth: 1
		qm_TextColor: "#ff181c31"
		qm_FillColor: "#ffff9a00"
		qm_Radius : 24
		qm_EllipseWidth: 48
		qm_EllipseHeight: 48
	}
	IGuiQmlRectangle
	{
		id: q671088652
		objId: 671088652
		x: 302
		y: 260
		width: 110
		height: 45
		qm_BorderWidth: 2
		qm_TextColor: "#ff181c31"
		qm_FillColor: "#ff9c3000"
		qm_RectangleWidth: 110
		qm_RectangleHeight: 45
	}
	IGuiBar
	{
		id: q50331648
		objId: 50331648
		x: 46
		y: 235
		width: 69
		height: 114
		qm_FillColor: "#fff7f3f7"
		qm_Font.pixelSize: 13
		qm_Font.family: "Tahoma"
		qm_Font.bold: true
		qm_BorderCornerRadius: 4
		qm_BorderWidth: 7
		qm_ImageSource: "image://QSmartImageProvider/25#2#4#128#0#0"
		qm_Border.top: 8
		qm_Border.bottom: 8
		qm_Border.right: 8
		qm_Border.left: 8
		qm_TextColor: "#ffff9a00"
		flowbarorientation: 0
		qm_segmentBar: 0
		barscaleplacement: 0
		barmarkerplacement: 2
		scaleposition: Qt.point(7,7)
		scaleheight: 84
		scalewidth: 44
		scalerectwidth: 55
		scalerectheight: 100
		scalelabelcolor: "#ff31344a"
		scaleorientation: 0
		scalepinwidth: 27
		scalepinheight: 1
		scalelabelwidth: 17
		scalelabelheight: 16
		scalemunitwidth: 0
		scaleinterval: 10
		scalelowvalue: 0.000000
		scalehighvalue: 10.000000
		scalelabellength: 2
		scaledecimalplaceno: 0
		scaleincrementlabelmark: 2
		scalesubdivisioncount: 5
		scaledetails: 1
		scalemeasurementunitid: -1
		scaleenlarge: 0
		bararrowtailwidth: 6
	}
	IGuiQmlCircle
	{
		id: q671088653
		objId: 671088653
		x: 17
		y: 161
		width: 29
		height: 29
		qm_BorderWidth: 1
		qm_TextColor: "#ff181c31"
		qm_FillColor: "#ffdedbde"
		qm_Radius : 14
		qm_EllipseWidth: 29
		qm_EllipseHeight: 29
	}
	IGuiQmlCircle
	{
		id: q671088654
		objId: 671088654
		x: 165
		y: 305
		width: 29
		height: 29
		qm_BorderWidth: 1
		qm_TextColor: "#ff181c31"
		qm_FillColor: "#ffdedbde"
		qm_Radius : 14
		qm_EllipseWidth: 29
		qm_EllipseHeight: 29
	}
	IGuiTextField
	{
		id: q268435467
		objId: 268435467
		x: 562
		y: 169
		width: 44
		height: 23
		qm_Transparent : true 
		qm_TextColor: "#ff31344a"
		qm_ValueVarTextAlignmentVertical: Text.AlignVCenter
		qm_Anchors.bottomMargin: 2
		qm_Anchors.leftMargin: 3
		qm_Anchors.rightMargin: 2
		qm_Anchors.topMargin: 2
	}
	IGuiTextField
	{
		id: q268435468
		objId: 268435468
		x: 719
		y: 305
		width: 44
		height: 23
		qm_Transparent : true 
		qm_TextColor: "#ff31344a"
		qm_ValueVarTextAlignmentVertical: Text.AlignVCenter
		qm_Anchors.bottomMargin: 2
		qm_Anchors.leftMargin: 3
		qm_Anchors.rightMargin: 2
		qm_Anchors.topMargin: 2
	}
	IGuiTextField
	{
		id: q268435469
		objId: 268435469
		x: 168
		y: 342
		width: 26
		height: 23
		qm_Transparent : true 
		qm_TextColor: "#ff31344a"
		qm_ValueVarTextAlignmentVertical: Text.AlignVCenter
		qm_Anchors.bottomMargin: 2
		qm_Anchors.leftMargin: 3
		qm_Anchors.rightMargin: 2
		qm_Anchors.topMargin: 2
	}
	IGuiTextField
	{
		id: q268435470
		objId: 268435470
		x: 20
		y: 198
		width: 26
		height: 23
		qm_Transparent : true 
		qm_TextColor: "#ff31344a"
		qm_ValueVarTextAlignmentVertical: Text.AlignVCenter
		qm_Anchors.bottomMargin: 2
		qm_Anchors.leftMargin: 3
		qm_Anchors.rightMargin: 2
		qm_Anchors.topMargin: 2
	}
	IGuiTextField
	{
		id: q268435471
		objId: 268435471
		x: 36
		y: 354
		width: 93
		height: 23
		qm_Transparent : true 
		qm_TextColor: "#ff31344a"
		qm_ValueVarTextAlignmentVertical: Text.AlignVCenter
		qm_Anchors.bottomMargin: 2
		qm_Anchors.leftMargin: 3
		qm_Anchors.rightMargin: 2
		qm_Anchors.topMargin: 2
	}
	IGuiButton
	{
		id: q486539314
		objId: 486539314
		x: 663
		y: 98
		width: 100
		height: 48
		qm_BorderCornerRadius: 3
		qm_BorderWidth: 2
		qm_ImageSource: "image://QSmartImageProvider/19#2#4#128#0#0"
		qm_Border.top: 15
		qm_Border.bottom: 15
		qm_Border.right: 5
		qm_Border.left: 5
		qm_FillColor: "#ff636573"
		qm_TextColor: "#ffffffff"
		qm_ValueVarTextAlignmentHorizontal: Text.AlignHCenter
		qm_ValueVarTextAlignmentVertical: Text.AlignVCenter
		qm_Anchors.bottomMargin: 2
		qm_Anchors.leftMargin: 2
		qm_Anchors.rightMargin: 2
		qm_Anchors.topMargin: 2
		qm_FocusWidth: 2
		qm_FocusColor: "#ff94b6e7"
	}
	IGuiButton
	{
		id: q486539315
		objId: 486539315
		x: 663
		y: 169
		width: 103
		height: 49
		qm_BorderCornerRadius: 3
		qm_BorderWidth: 2
		qm_ImageSource: "image://QSmartImageProvider/19#2#4#128#0#0"
		qm_Border.top: 15
		qm_Border.bottom: 15
		qm_Border.right: 5
		qm_Border.left: 5
		qm_FillColor: "#ff636573"
		qm_TextColor: "#ffffffff"
		qm_ValueVarTextAlignmentHorizontal: Text.AlignHCenter
		qm_ValueVarTextAlignmentVertical: Text.AlignVCenter
		qm_Anchors.bottomMargin: 2
		qm_Anchors.leftMargin: 2
		qm_Anchors.rightMargin: 2
		qm_Anchors.topMargin: 2
		qm_FocusWidth: 2
		qm_FocusColor: "#ff94b6e7"
	}
	IGuiQmlCircle
	{
		id: q671088656
		objId: 671088656
		x: 17
		y: 66
		width: 29
		height: 29
		qm_BorderWidth: 1
		qm_TextColor: "#ff181c31"
		qm_FillColor: "#ffdedbde"
		qm_Radius : 14
		qm_EllipseWidth: 29
		qm_EllipseHeight: 29
	}
	IGuiTextField
	{
		id: q268435474
		objId: 268435474
		x: 47
		y: 70
		width: 58
		height: 23
		qm_Transparent : true 
		qm_TextColor: "#ff31344a"
		qm_ValueVarTextAlignmentVertical: Text.AlignVCenter
		qm_Anchors.bottomMargin: 2
		qm_Anchors.leftMargin: 3
		qm_Anchors.rightMargin: 2
		qm_Anchors.topMargin: 2
	}
	IGuiButton
	{
		id: q486539316
		objId: 486539316
		x: 692
		y: 399
		width: 96
		height: 45
		qm_BorderCornerRadius: 3
		qm_BorderWidth: 2
		qm_ImageSource: "image://QSmartImageProvider/19#2#4#128#0#0"
		qm_Border.top: 15
		qm_Border.bottom: 15
		qm_Border.right: 5
		qm_Border.left: 5
		qm_FillColor: "#ff636573"
		qm_TextColor: "#ffffffff"
		qm_ValueVarTextAlignmentHorizontal: Text.AlignHCenter
		qm_ValueVarTextAlignmentVertical: Text.AlignVCenter
		qm_Anchors.bottomMargin: 2
		qm_Anchors.leftMargin: 2
		qm_Anchors.rightMargin: 2
		qm_Anchors.topMargin: 2
		qm_FocusWidth: 2
		qm_FocusColor: "#ff94b6e7"
	}
	IGuiQmlRectangle
	{
		id: q671088657
		objId: 671088657
		x: 536
		y: 260
		width: 110
		height: 45
		qm_BorderWidth: 2
		qm_TextColor: "#ff181c31"
		qm_FillColor: "#ff9c3000"
		qm_RectangleWidth: 110
		qm_RectangleHeight: 45
	}
	IGuiQmlCircle
	{
		id: q671088658
		objId: 671088658
		x: 535
		y: 130
		width: 48
		height: 48
		qm_BorderWidth: 1
		qm_TextColor: "#ff181c31"
		qm_FillColor: "#ffff9a00"
		qm_Radius : 24
		qm_EllipseWidth: 48
		qm_EllipseHeight: 48
	}
	IGuiQmlCircle
	{
		id: q671088659
		objId: 671088659
		x: 359
		y: 109
		width: 48
		height: 48
		qm_BorderWidth: 1
		qm_TextColor: "#ff181c31"
		qm_FillColor: "#ffff9a00"
		qm_Radius : 24
		qm_EllipseWidth: 48
		qm_EllipseHeight: 48
	}
	IGuiQmlCircle
	{
		id: q671088660
		objId: 671088660
		x: 173
		y: 109
		width: 48
		height: 48
		qm_BorderWidth: 1
		qm_TextColor: "#ff181c31"
		qm_FillColor: "#ffff9a00"
		qm_Radius : 24
		qm_EllipseWidth: 48
		qm_EllipseHeight: 48
	}
	IGuiQmlCircle
	{
		id: q671088661
		objId: 671088661
		x: 562
		y: 187
		width: 48
		height: 48
		qm_BorderWidth: 1
		qm_TextColor: "#ff181c31"
		qm_FillColor: "#ffff9a00"
		qm_Radius : 24
		qm_EllipseWidth: 48
		qm_EllipseHeight: 48
	}
	IGuiQmlCircle
	{
		id: q671088662
		objId: 671088662
		x: 471
		y: 109
		width: 48
		height: 48
		qm_BorderWidth: 1
		qm_TextColor: "#ff181c31"
		qm_FillColor: "#ffff9a00"
		qm_Radius : 24
		qm_EllipseWidth: 48
		qm_EllipseHeight: 48
	}
}
